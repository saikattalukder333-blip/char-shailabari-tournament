CHAR SHAILABARI TOURNAMENT WEBSITE
=================================
Files:
- index.html : complete static website

Included:
- Professional responsive Champions-League-inspired design
- Tournament home page
- 10 teams / 2 groups
- Fixtures & results
- Group A/B standings
- Yellow-card column
- Saluavita squad
- Demo live-score controls
- Demo admin panel (password: admin2026)
- Browser localStorage score saving

Important:
This is a static website. The admin/live score is browser-local only.
For a truly shared online live score, a database + secure authentication/backend is required.
